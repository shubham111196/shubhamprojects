package secure;
import java.sql.*;
import javax.swing.*;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author shubham
 */
class MySqlConnect_1 {
    Connection conn=null;
    public static Connection ConnectDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/bloodbank","root","11111996");
            JOptionPane.showMessageDialog(null,"Connected to DATABASE");
            return conn;
        }
        catch(Exception e){
          JOptionPane.showMessageDialog(null, e);  
          return null;
        }
    }
    
}
